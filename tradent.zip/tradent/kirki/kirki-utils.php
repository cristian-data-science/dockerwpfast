<?php
function tradent_kirki_config() {
	return 'tradent_kirki_config';
}

function tradent_defaults( $key = '' ) {
	$defaults = array();

	# site identify
	$defaults['use-custom-logo'] = '1';
	$defaults['custom-logo'] = TRADENT_THEME_URI.'/images/logo.png';
	$defaults['custom-light-logo'] = TRADENT_THEME_URI.'/images/light-logo.png';
	$defaults['site_icon'] = TRADENT_THEME_URI.'/images/favicon.ico';

	# site layout
	$defaults['site-layout'] = 'wide';

	# site skin
	$defaults['primary-color']      = '#fabe2c';
	$defaults['secondary-color']    = '#05305c';
	$defaults['tertiary-color']     = '#04172a';
	$defaults['body-bg-color']      = '#ffffff';
	$defaults['body-content-color'] = '#777777';
	$defaults['body-a-color']       = '#000000';
	$defaults['body-a-hover-color'] = '#fabe2c';
	

	# site breadcrumb
	$defaults['customize-breadcrumb-title-typo'] = '1';
	$defaults['breadcrumb-title-typo'] = array( 'font-family' => 'Montserrat',
		'variant' => '600',
		'subsets' => array( 'latin-ext' ),
		'font-size' => '50px',
		'line-height' => 'normal',
		'letter-spacing' => '0.5px',
		'color' => '#ffffff',
		'text-align' => 'unset',
		'text-transform' => 'none' );
	$defaults['customize-breadcrumb-typo'] = '0';
	$defaults['breadcrumb-typo'] = array( 'font-family' => 'Open Sans',
		'variant' => 'regular',
		'subsets' => array( 'latin-ext' ),
		'font-size' => '13px',
		'line-height' => 'normal',
		'letter-spacing' => '0',
		'color' => '',
		'text-align' => 'unset',
		'text-transform' => 'none' );

	# site footer
	$defaults['customize-footer-title-typo'] = '1';
	$defaults['footer-title-typo'] = array( 'font-family' => 'Open Sans',
		'variant' => '700',
		'subsets' => array( 'latin-ext' ),
		'font-size' => '20px',
		'line-height' => '36px',
		'letter-spacing' => '0',
		'color' => '#ffffff',
		'text-align' => 'left',
		'text-transform' => 'none' );
	$defaults['customize-footer-content-typo'] = '1';
	$defaults['footer-content-typo'] = array( 'font-family' => 'Open Sans',
		'variant' => 'regular',
		'subsets' => array( 'latin-ext' ),
		'font-size' => '14px',
		'line-height' => '24px',
		'letter-spacing' => '0',
		'color' => '#333333',
		'text-align' => 'left',
		'text-transform' => 'none' );

	# site typography
	$defaults['customize-body-h1-typo'] = '1';
	$defaults['h1'] = array(
		'font-family' => 'Raleway',
		'variant' => '500',
		'font-size' => '36px',
		'line-height' => 'normal',
		'letter-spacing' => '0.5px',
		'color' => '#111111',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);
	$defaults['customize-body-h2-typo'] = '1';
	$defaults['h2'] = array(
		'font-family' => 'Raleway',
		'variant' => '500',
		'font-size' => '30px',
		'line-height' => 'normal',
		'letter-spacing' => '0.5px',
		'color' => '#333333',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);
	$defaults['customize-body-h3-typo'] = '1';
	$defaults['h3'] = array(
		'font-family' => 'Raleway',
		'variant' => '500',
		'font-size' => '24px',
		'line-height' => 'normal',
		'letter-spacing' => '0.5px',
		'color' => '#111111',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);
	$defaults['customize-body-h4-typo'] = '1';
	$defaults['h4'] = array(
		'font-family' => 'Raleway',
		'variant' => '500',
		'font-size' => '22px',
		'line-height' => 'normal',
		'letter-spacing' => '0.5px',
		'color' => '#111111',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);
	$defaults['customize-body-h5-typo'] = '1';
	$defaults['h5'] = array(
		'font-family' => 'Raleway',
		'variant' => '500',
		'font-size' => '20px',
		'line-height' => 'normal',
		'letter-spacing' => '0.5px',
		'color' => '#111111',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);
	$defaults['customize-body-h6-typo'] = '1';
	$defaults['h6'] = array(
		'font-family' => 'Raleway',
		'variant' => '500',
		'font-size' => '18px',
		'line-height' => 'normal',
		'letter-spacing' => '0.5px',
		'color' => '#111111',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);
	$defaults['customize-body-content-typo'] = '1';
	$defaults['body-content-typo'] = array(
		'font-family' => 'Open Sans',
		'variant' => 'regular',
		'font-size' => '16px',
		'line-height' => '28px',
		'letter-spacing' => '0.5px',
		'color' => '#777777',
		'text-align' => 'unset',
		'text-transform' => 'none'
	);

	$defaults['footer-content-a-color'] = '';
	$defaults['footer-content-a-hover-color'] = '';

	if( !empty( $key ) && array_key_exists( $key, $defaults) ) {
		return $defaults[$key];
	}

	return '';
}

function tradent_image_positions() {

	$positions = array( "top left" => esc_attr__('Top Left','tradent'),
		"top center"    => esc_attr__('Top Center','tradent'),
		"top right"     => esc_attr__('Top Right','tradent'),
		"center left"   => esc_attr__('Center Left','tradent'),
		"center center" => esc_attr__('Center Center','tradent'),
		"center right"  => esc_attr__('Center Right','tradent'),
		"bottom left"   => esc_attr__('Bottom Left','tradent'),
		"bottom center" => esc_attr__('Bottom Center','tradent'),
		"bottom right"  => esc_attr__('Bottom Right','tradent'),
	);

	return $positions;
}

function tradent_image_repeats() {

	$image_repeats = array( "repeat" => esc_attr__('Repeat','tradent'),
		"repeat-x"  => esc_attr__('Repeat in X-axis','tradent'),
		"repeat-y"  => esc_attr__('Repeat in Y-axis','tradent'),
		"no-repeat" => esc_attr__('No Repeat','tradent')
	);

	return $image_repeats;
}

function tradent_border_styles() {

	$image_repeats = array(
		"none"	 => esc_attr__('None','tradent'),
		"dotted" => esc_attr__('Dotted','tradent'),
		"dashed" => esc_attr__('Dashed','tradent'),
		"solid"	 => esc_attr__('Solid','tradent'),
		"double" => esc_attr__('Double','tradent'),
		"groove" => esc_attr__('Groove','tradent'),
		"ridge"	 => esc_attr__('Ridge','tradent'),
	);

	return $image_repeats;
}

function tradent_animations() {

	$animations = array(
		'' 					 => esc_html__('Default','tradent'),	
		"bigEntrance"        =>  esc_attr__("bigEntrance",'tradent'),
        "bounce"             =>  esc_attr__("bounce",'tradent'),
        "bounceIn"           =>  esc_attr__("bounceIn",'tradent'),
        "bounceInDown"       =>  esc_attr__("bounceInDown",'tradent'),
        "bounceInLeft"       =>  esc_attr__("bounceInLeft",'tradent'),
        "bounceInRight"      =>  esc_attr__("bounceInRight",'tradent'),
        "bounceInUp"         =>  esc_attr__("bounceInUp",'tradent'),
        "bounceOut"          =>  esc_attr__("bounceOut",'tradent'),
        "bounceOutDown"      =>  esc_attr__("bounceOutDown",'tradent'),
        "bounceOutLeft"      =>  esc_attr__("bounceOutLeft",'tradent'),
        "bounceOutRight"     =>  esc_attr__("bounceOutRight",'tradent'),
        "bounceOutUp"        =>  esc_attr__("bounceOutUp",'tradent'),
        "expandOpen"         =>  esc_attr__("expandOpen",'tradent'),
        "expandUp"           =>  esc_attr__("expandUp",'tradent'),
        "fadeIn"             =>  esc_attr__("fadeIn",'tradent'),
        "fadeInDown"         =>  esc_attr__("fadeInDown",'tradent'),
        "fadeInDownBig"      =>  esc_attr__("fadeInDownBig",'tradent'),
        "fadeInLeft"         =>  esc_attr__("fadeInLeft",'tradent'),
        "fadeInLeftBig"      =>  esc_attr__("fadeInLeftBig",'tradent'),
        "fadeInRight"        =>  esc_attr__("fadeInRight",'tradent'),
        "fadeInRightBig"     =>  esc_attr__("fadeInRightBig",'tradent'),
        "fadeInUp"           =>  esc_attr__("fadeInUp",'tradent'),
        "fadeInUpBig"        =>  esc_attr__("fadeInUpBig",'tradent'),
        "fadeOut"            =>  esc_attr__("fadeOut",'tradent'),
        "fadeOutDownBig"     =>  esc_attr__("fadeOutDownBig",'tradent'),
        "fadeOutLeft"        =>  esc_attr__("fadeOutLeft",'tradent'),
        "fadeOutLeftBig"     =>  esc_attr__("fadeOutLeftBig",'tradent'),
        "fadeOutRight"       =>  esc_attr__("fadeOutRight",'tradent'),
        "fadeOutUp"          =>  esc_attr__("fadeOutUp",'tradent'),
        "fadeOutUpBig"       =>  esc_attr__("fadeOutUpBig",'tradent'),
        "flash"              =>  esc_attr__("flash",'tradent'),
        "flip"               =>  esc_attr__("flip",'tradent'),
        "flipInX"            =>  esc_attr__("flipInX",'tradent'),
        "flipInY"            =>  esc_attr__("flipInY",'tradent'),
        "flipOutX"           =>  esc_attr__("flipOutX",'tradent'),
        "flipOutY"           =>  esc_attr__("flipOutY",'tradent'),
        "floating"           =>  esc_attr__("floating",'tradent'),
        "hatch"              =>  esc_attr__("hatch",'tradent'),
        "hinge"              =>  esc_attr__("hinge",'tradent'),
        "lightSpeedIn"       =>  esc_attr__("lightSpeedIn",'tradent'),
        "lightSpeedOut"      =>  esc_attr__("lightSpeedOut",'tradent'),
        "pullDown"           =>  esc_attr__("pullDown",'tradent'),
        "pullUp"             =>  esc_attr__("pullUp",'tradent'),
        "pulse"              =>  esc_attr__("pulse",'tradent'),
        "rollIn"             =>  esc_attr__("rollIn",'tradent'),
        "rollOut"            =>  esc_attr__("rollOut",'tradent'),
        "rotateIn"           =>  esc_attr__("rotateIn",'tradent'),
        "rotateInDownLeft"   =>  esc_attr__("rotateInDownLeft",'tradent'),
        "rotateInDownRight"  =>  esc_attr__("rotateInDownRight",'tradent'),
        "rotateInUpLeft"     =>  esc_attr__("rotateInUpLeft",'tradent'),
        "rotateInUpRight"    =>  esc_attr__("rotateInUpRight",'tradent'),
        "rotateOut"          =>  esc_attr__("rotateOut",'tradent'),
        "rotateOutDownRight" =>  esc_attr__("rotateOutDownRight",'tradent'),
        "rotateOutUpLeft"    =>  esc_attr__("rotateOutUpLeft",'tradent'),
        "rotateOutUpRight"   =>  esc_attr__("rotateOutUpRight",'tradent'),
        "shake"              =>  esc_attr__("shake",'tradent'),
        "slideDown"          =>  esc_attr__("slideDown",'tradent'),
        "slideExpandUp"      =>  esc_attr__("slideExpandUp",'tradent'),
        "slideLeft"          =>  esc_attr__("slideLeft",'tradent'),
        "slideRight"         =>  esc_attr__("slideRight",'tradent'),
        "slideUp"            =>  esc_attr__("slideUp",'tradent'),
        "stretchLeft"        =>  esc_attr__("stretchLeft",'tradent'),
        "stretchRight"       =>  esc_attr__("stretchRight",'tradent'),
        "swing"              =>  esc_attr__("swing",'tradent'),
        "tada"               =>  esc_attr__("tada",'tradent'),
        "tossing"            =>  esc_attr__("tossing",'tradent'),
        "wobble"             =>  esc_attr__("wobble",'tradent'),
        "fadeOutDown"        =>  esc_attr__("fadeOutDown",'tradent'),
        "fadeOutRightBig"    =>  esc_attr__("fadeOutRightBig",'tradent'),
        "rotateOutDownLeft"  =>  esc_attr__("rotateOutDownLeft",'tradent')
    );

	return $animations;
}