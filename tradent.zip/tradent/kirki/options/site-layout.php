<?php
$config = tradent_kirki_config();

TRADENT_Kirki::add_section( 'dt_site_layout_section', array(
	'title' => esc_html__( 'Site Layout', 'tradent' ),
	'priority' => 20
) );

	# site-layout
	TRADENT_Kirki::add_field( $config, array(
		'type'     => 'radio-image',
		'settings' => 'site-layout',
		'label'    => esc_html__( 'Site Layout', 'tradent' ),
		'section'  => 'dt_site_layout_section',
		'default'  => tradent_defaults('site-layout'),
		'choices' => array(
			'boxed' =>  TRADENT_THEME_URI.'/kirki/assets/images/site-layout/boxed.png',
			'wide' => TRADENT_THEME_URI.'/kirki/assets/images/site-layout/wide.png',
		)
	));

	# site-boxed-layout
	TRADENT_Kirki::add_field( $config, array(
		'type'     => 'switch',
		'settings' => 'site-boxed-layout',
		'label'    => esc_html__( 'Customize Boxed Layout?', 'tradent' ),
		'section'  => 'dt_site_layout_section',
		'default'  => '1',
		'choices'  => array(
			'on'  => esc_attr__( 'Yes', 'tradent' ),
			'off' => esc_attr__( 'No', 'tradent' )
		),
		'active_callback' => array(
			array( 'setting' => 'site-layout', 'operator' => '==', 'value' => 'boxed' ),
		)			
	));

	# body-bg-type
	TRADENT_Kirki::add_field( $config, array(
		'type' => 'select',
		'settings' => 'body-bg-type',
		'label'    => esc_html__( 'Background Type', 'tradent' ),
		'section'  => 'dt_site_layout_section',
		'multiple' => 1,
		'default'  => 'none',
		'choices'  => array(
			'pattern' => esc_attr__( 'Predefined Patterns', 'tradent' ),
			'upload' => esc_attr__( 'Set Pattern', 'tradent' ),
			'none' => esc_attr__( 'None', 'tradent' ),
		),
		'active_callback' => array(
			array( 'setting' => 'site-layout', 'operator' => '==', 'value' => 'boxed' ),
			array( 'setting' => 'site-boxed-layout', 'operator' => '==', 'value' => '1' )
		)
	));

	# body-bg-pattern
	TRADENT_Kirki::add_field( $config, array(
		'type'     => 'radio-image',
		'settings' => 'body-bg-pattern',
		'label'    => esc_html__( 'Predefined Patterns', 'tradent' ),
		'description'    => esc_html__( 'Add Background for body', 'tradent' ),
		'section'  => 'dt_site_layout_section',
		'output' => array(
			array( 'element' => 'body' , 'property' => 'background-image' )
		),
		'choices' => array(
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern1.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern1.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern2.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern2.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern3.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern3.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern4.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern4.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern5.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern5.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern6.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern6.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern7.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern7.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern8.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern8.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern9.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern9.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern10.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern10.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern11.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern11.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern12.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern12.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern13.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern13.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern14.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern14.jpg',
			TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern15.jpg'=> TRADENT_THEME_URI.'/kirki/assets/images/site-layout/pattern15.jpg',
		),
		'active_callback' => array(
			array( 'setting' => 'body-bg-type', 'operator' => '==', 'value' => 'pattern' ),
			array( 'setting' => 'site-layout', 'operator' => '==', 'value' => 'boxed' ),
			array( 'setting' => 'site-boxed-layout', 'operator' => '==', 'value' => '1' )
		)						
	));

	# body-bg-image
	TRADENT_Kirki::add_field( $config, array(
		'type' => 'image',
		'settings' => 'body-bg-image',
		'label'    => esc_html__( 'Background Image', 'tradent' ),
		'description'    => esc_html__( 'Add Background Image for body', 'tradent' ),
		'section'  => 'dt_site_layout_section',
		'output' => array(
			array( 'element' => 'body' , 'property' => 'background-image' )
		),
		'active_callback' => array(
			array( 'setting' => 'body-bg-type', 'operator' => '==', 'value' => 'upload' ),
			array( 'setting' => 'site-layout', 'operator' => '==', 'value' => 'boxed' ),
			array( 'setting' => 'site-boxed-layout', 'operator' => '==', 'value' => '1' )
		)
	));

	# body-bg-position
	TRADENT_Kirki::add_field( $config, array(
		'type' => 'select',
		'settings' => 'body-bg-position',
		'label'    => esc_html__( 'Background Position', 'tradent' ),
		'section'  => 'dt_site_layout_section',
		'output' => array(
			array( 'element' => 'body' , 'property' => 'background-position' )
		),
		'default' => 'center',
		'multiple' => 1,
		'choices' => tradent_image_positions(),
		'active_callback' => array(
			array( 'setting' => 'body-bg-type', 'operator' => 'contains', 'value' => array( 'pattern', 'upload') ),
			array( 'setting' => 'site-layout', 'operator' => '==', 'value' => 'boxed' ),
			array( 'setting' => 'site-boxed-layout', 'operator' => '==', 'value' => '1' )
		)
	));

	# body-bg-repeat
	TRADENT_Kirki::add_field( $config, array(
		'type' => 'select',
		'settings' => 'body-bg-repeat',
		'label'    => esc_html__( 'Background Repeat', 'tradent' ),
		'section'  => 'dt_site_layout_section',
		'output' => array(
			array( 'element' => 'body' , 'property' => 'background-repeat' )
		),
		'default' => 'repeat',
		'multiple' => 1,
		'choices' => tradent_image_repeats(),
		'active_callback' => array(
			array( 'setting' => 'body-bg-type', 'operator' => 'contains', 'value' => array( 'pattern', 'upload' ) ),
			array( 'setting' => 'site-layout', 'operator' => '==', 'value' => 'boxed' ),
			array( 'setting' => 'site-boxed-layout', 'operator' => '==', 'value' => '1' )
		)
	));	