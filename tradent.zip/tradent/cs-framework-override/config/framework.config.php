<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings           = array(
  'menu_title'      => constant('TRADENT_THEME_NAME').' '.esc_html__('Options', 'tradent'),
  'menu_type'       => 'theme', // menu, submenu, options, theme, etc.
  'menu_slug'       => 'cs-framework',
  'ajax_save'       => true,
  'show_reset_all'  => false,
  'framework_title' => sprintf( esc_html__('Designthemes Framework %sby Designthemes%s', 'tradent'), '<small>', '</small>')
);

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options        = array();

$options[]      = array(
  'name'        => 'general',
  'title'       => esc_html__('General', 'tradent'),
  'icon'        => 'fa fa-gears',

  'fields'      => array(

	array(
	  'type'    => 'subheading',
	  'content' => esc_html__( 'General Options', 'tradent' ),
	),
	
	array(
		'id'	=> 'header',
		'type'	=> 'select',
		'title'	=> esc_html__('Site Header', 'tradent'),
		'class'	=> 'chosen',
		'options'	=> 'posts',
		'query_args'	=> array(
			'post_type'	=> 'dt_headers',
			'orderby'	=> 'title',
			'order'	=> 'ASC',
			'posts_per_page' => -1
		),
		'default_option'	=> esc_attr__('Select Header', 'tradent'),
		'attributes'	=> array ( 'style'	=> 'width:50%'),
		'info'	=> esc_html__('Select default header.','tradent'),
	),
	
	array(
		'id'	=> 'footer',
		'type'	=> 'select',
		'title'	=> esc_html__('Site Footer', 'tradent'),
		'class'	=> 'chosen',
		'options'	=> 'posts',
		'query_args'	=> array(
			'post_type'	=> 'dt_footers',
			'orderby'	=> 'title',
			'order'	=> 'ASC',
			'posts_per_page' => -1
		),
		'default_option'	=> esc_attr__('Select Footer', 'tradent'),
		'attributes'	=> array ( 'style'	=> 'width:50%'),
		'info'	=> esc_html__('Select defaultfooter.','tradent'),
	),

	array(
	  'id'  	 => 'use-site-loader',
	  'type'  	 => 'switcher',
	  'title' 	 => esc_html__('Site Loader', 'tradent'),
	  'info'	 => esc_html__('YES! to use site loader.', 'tradent')
	),	

	array(
	  'id'  	 => 'enable-stylepicker',
	  'type'  	 => 'switcher',
	  'title' 	 => esc_html__('Style Picker', 'tradent'),
	  'info'	 => esc_html__('YES! to show the style picker.', 'tradent')
	),		

	array(
	  'id'  	 => 'show-pagecomments',
	  'type'  	 => 'switcher',
	  'title' 	 => esc_html__('Globally Show Page Comments', 'tradent'),
	  'info'	 => esc_html__('YES! to show comments on all the pages. This will globally override your "Allow comments" option under your page "Discussion" settings.', 'tradent'),
	  'default'  => true,
	),

	array(
	  'id'  	 => 'showall-pagination',
	  'type'  	 => 'switcher',
	  'title' 	 => esc_html__('Show all pages in Pagination', 'tradent'),
	  'info'	 => esc_html__('YES! to show all the pages instead of dots near the current page.', 'tradent')
	),



	array(
	  'id'      => 'google-map-key',
	  'type'    => 'text',
	  'title'   => esc_html__('Google Map API Key', 'tradent'),
	  'after' 	=> '<p class="cs-text-info">'.esc_html__('Put a valid google account api key here', 'tradent').'</p>',
	),

	array(
	  'id'      => 'mailchimp-key',
	  'type'    => 'text',
	  'title'   => esc_html__('Mailchimp API Key', 'tradent'),
	  'after' 	=> '<p class="cs-text-info">'.esc_html__('Put a valid mailchimp account api key here', 'tradent').'</p>',
	),

  ),
);

$options[]      = array(
  'name'        => 'layout_options',
  'title'       => esc_html__('Layout Options', 'tradent'),
  'icon'        => 'dashicons dashicons-exerpt-view',
  'sections' => array(

	// -----------------------------------------
	// Header Options
	// -----------------------------------------
	array(
	  'name'      => 'breadcrumb_options',
	  'title'     => esc_html__('Breadcrumb Options', 'tradent'),
	  'icon'      => 'fa fa-sitemap',

		'fields'      => array(

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Breadcrumb Options", 'tradent' ),
		  ),

		  array(
			'id'  		 => 'show-breadcrumb',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Show Breadcrumb', 'tradent'),
			'info'		 => esc_html__('YES! to display breadcrumb for all pages.', 'tradent'),
			'default' 	 => true,
		  ),

		  array(
			'id'           => 'breadcrumb-delimiter',
			'type'         => 'icon',
			'title'        => esc_html__('Breadcrumb Delimiter', 'tradent'),
			'info'         => esc_html__('Choose delimiter style to display on breadcrumb section.', 'tradent'),
			'default'      => 'fa fa-angle-double-right',
		  ),

		  array(
			'id'           => 'breadcrumb-style',
			'type'         => 'select',
			'title'        => esc_html__('Breadcrumb Style', 'tradent'),
			'options'      => array(
			  'default' 							=> esc_html__('Default', 'tradent'),
			  'aligncenter'    						=> esc_html__('Align Center', 'tradent'),
			  'alignright'  						=> esc_html__('Align Right', 'tradent'),
			  'breadcrumb-left'    					=> esc_html__('Left Side Breadcrumb', 'tradent'),
			  'breadcrumb-right'     				=> esc_html__('Right Side Breadcrumb', 'tradent'),
			  'breadcrumb-top-right-title-center'  	=> esc_html__('Top Right Title Center', 'tradent'),
			  'breadcrumb-top-left-title-center'  	=> esc_html__('Top Left Title Center', 'tradent'),
			),
			'class'        => 'chosen',
			'default'      => 'default',
			'info'         => esc_html__('Choose alignment style to display on breadcrumb section.', 'tradent'),
		  ),

		  array(
			  'id'                 => 'breadcrumb-position',
			  'type'               => 'select',
			  'title'              => esc_html__('Position', 'tradent' ),
			  'options'            => array(
				  'header-top-absolute'    => esc_html__('Behind the Header','tradent'),
				  'header-top-relative'    => esc_html__('Default','tradent'),
			  ),
			  'class'        => 'chosen',
			  'default'      => 'header-top-relative',
			  'info'         => esc_html__('Choose position of breadcrumb section.', 'tradent'),
		  ),

		  array(
			'id'    => 'breadcrumb_background',
			'type'  => 'background',
			'title' => esc_html__('Background', 'tradent'),
			'desc'  => esc_html__('Choose background options for breadcrumb title section.', 'tradent'),
	        'default' => array(
	            'image'      => TRADENT_THEME_URI . '/images/breadcrumb.png',
	        ),				
		  ),

		),
	),

  ),
);

$options[]      = array(
  'name'        => 'allpage_options',
  'title'       => esc_html__('All Page Options', 'tradent'),
  'icon'        => 'fa fa-files-o',
  'sections' => array(

	// -----------------------------------------
	// Post Options
	// -----------------------------------------
	array(
	  'name'      => 'post_options',
	  'title'     => esc_html__('Post Options', 'tradent'),
	  'icon'      => 'fa fa-file',

		'fields'      => array(

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Single Post Options", 'tradent' ),
		  ),
		
		  array(
			'id'  		 => 'single-post-authorbox',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Single Author Box', 'tradent'),
			'info'		 => esc_html__('YES! to display author box in single blog posts.', 'tradent')
		  ),

		  array(
			'id'  		 => 'single-post-related',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Single Related Posts', 'tradent'),
			'info'		 => esc_html__('YES! to display related blog posts in single posts.', 'tradent')
		  ),

		  array(
			'id'  		 => 'single-post-navigation',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Single Post Navigation', 'tradent'),
			'info'		 => esc_html__('YES! to display post navigation in single posts.', 'tradent')
		  ),

		  array(
			'id'  		 => 'single-post-comments',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Posts Comments', 'tradent'),
			'info'		 => esc_html__('YES! to display single blog post comments.', 'tradent'),
			'default' 	 => true,
		  ),

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Post Archives Page Layout", 'tradent' ),
		  ),

		  array(
			'id'      	 => 'post-archives-page-layout',
			'type'       => 'image_select',
			'title'      => esc_html__('Page Layout', 'tradent'),
			'options'    => array(
			  'content-full-width'   => TRADENT_THEME_URI . '/cs-framework-override/images/without-sidebar.png',
			  'with-left-sidebar'    => TRADENT_THEME_URI . '/cs-framework-override/images/left-sidebar.png',
			  'with-right-sidebar'   => TRADENT_THEME_URI . '/cs-framework-override/images/right-sidebar.png',
			  'with-both-sidebar'    => TRADENT_THEME_URI . '/cs-framework-override/images/both-sidebar.png',
			),
			'default'      => 'content-full-width',
			'attributes'   => array(
			  'data-depend-id' => 'post-archives-page-layout',
			),
		  ),

		  array(
			'id'  		 => 'show-standard-left-sidebar-for-post-archives',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Show Standard Left Sidebar', 'tradent'),
			'dependency' => array( 'post-archives-page-layout', 'any', 'with-left-sidebar,with-both-sidebar' ),
		  ),

		  array(
			'id'  		 => 'show-standard-right-sidebar-for-post-archives',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Show Standard Right Sidebar', 'tradent'),
			'dependency' => array( 'post-archives-page-layout', 'any', 'with-right-sidebar,with-both-sidebar' ),
		  ),

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Post Archives Post Layout", 'tradent' ),
		  ),

		  array(
			'id'      	   => 'post-archives-post-layout',
			'type'         => 'image_select',
			'title'        => esc_html__('Post Layout', 'tradent'),
			'options'      => array(
			  'one-column' 		  => TRADENT_THEME_URI . '/cs-framework-override/images/one-column.png',
			  'one-half-column'   => TRADENT_THEME_URI . '/cs-framework-override/images/one-half-column.png',
			  'one-third-column'  => TRADENT_THEME_URI . '/cs-framework-override/images/one-third-column.png',
			  '1-2-2'			  => TRADENT_THEME_URI . '/cs-framework-override/images/1-2-2.png',
			  '1-2-2-1-2-2' 	  => TRADENT_THEME_URI . '/cs-framework-override/images/1-2-2-1-2-2.png',
			  '1-3-3-3'			  => TRADENT_THEME_URI . '/cs-framework-override/images/1-3-3-3.png',
			  '1-3-3-3-1' 		  => TRADENT_THEME_URI . '/cs-framework-override/images/1-3-3-3-1.png',
			),
			'default'      => 'one-half-column',
		  ),

		  array(
			'id'           => 'post-style',
			'type'         => 'select',
			'title'        => esc_html__('Post Style', 'tradent'),
			'options'      => array(
			  'blog-default-style' 		=> esc_html__('Default', 'tradent'),
			  'entry-date-left'      	=> esc_html__('Date Left', 'tradent'),
			  'entry-date-left outer-frame-border'      	=> esc_html__('Date Left Modern', 'tradent'),
			  'entry-date-author-left'  => esc_html__('Date and Author Left', 'tradent'),
			  'blog-modern-style'       => esc_html__('Modern', 'tradent'),
			  'bordered'      			=> esc_html__('Bordered', 'tradent'),
			  'classic'      			=> esc_html__('Classic', 'tradent'),
			  'entry-overlay-style' 	=> esc_html__('Trendy', 'tradent'),
			  'overlap' 				=> esc_html__('Overlap', 'tradent'),
			  'entry-center-align'		=> esc_html__('Stripe', 'tradent'),
			  'entry-fashion-style'	 	=> esc_html__('Fashion', 'tradent'),
			  'entry-minimal-bordered' 	=> esc_html__('Minimal Bordered', 'tradent'),
			  'blog-medium-style'       => esc_html__('Medium', 'tradent'),
			  'blog-medium-style dt-blog-medium-highlight'     					 => esc_html__('Medium Hightlight', 'tradent'),
			  'blog-medium-style dt-blog-medium-highlight dt-sc-skin-highlight'  => esc_html__('Medium Skin Highlight', 'tradent'),
			),
			'class'        => 'chosen',
			'default'      => 'blog-default-style',
			'info'         => esc_html__('Choose post style to display post archives pages.', 'tradent'),
		  ),

		  array(
			'id'  		 => 'post-archives-enable-excerpt',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Allow Excerpt', 'tradent'),
			'info'		 => esc_html__('YES! to allow excerpt', 'tradent'),
			'default'    => true,
		  ),

		  array(
			'id'  		 => 'post-archives-excerpt',
			'type'  	 => 'number',
			'title' 	 => esc_html__('Excerpt Length', 'tradent'),
			'after'		 => '<span class="cs-text-desc">&nbsp;'.esc_html__('Put Excerpt Length', 'tradent').'</span>',
			'default' 	 => 40,
		  ),

		  array(
			'id'  		 => 'post-archives-enable-readmore',
			'type'  	 => 'switcher',
			'title' 	 => esc_html__('Read More', 'tradent'),
			'info'		 => esc_html__('YES! to enable read more button', 'tradent'),
			'default'	 => true,
		  ),

		  array(
			'id'  		 => 'post-archives-readmore',
			'type'  	 => 'textarea',
			'title' 	 => esc_html__('Read More Shortcode', 'tradent'),
			'info'		 => esc_html__('Paste any button shortcode here', 'tradent'),
			'default'	 => '[dt_sc_button title="Continue Reading " style="filled" class=" dt-sc-readmore-link"]',
		  ),

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Single Post & Post Archive options", 'tradent' ),
		  ),

		  array(
			'id'      => 'post-format-meta',
			'type'    => 'switcher',
			'title'   => esc_html__('Post Format Meta', 'tradent' ),
			'info'	  => esc_html__('YES! to show post format meta information', 'tradent'),
			'default' => true
		  ),

		  array(
			'id'      => 'post-author-meta',
			'type'    => 'switcher',
			'title'   => esc_html__('Author Meta', 'tradent' ),
			'info'	  => esc_html__('YES! to show post author meta information', 'tradent'),
			'default' => true
		  ),

		  array(
			'id'      => 'post-date-meta',
			'type'    => 'switcher',
			'title'   => esc_html__('Date Meta', 'tradent' ),
			'info'	  => esc_html__('YES! to show post date meta information', 'tradent'),
			'default' => true
		  ),

		  array(
			'id'      => 'post-comment-meta',
			'type'    => 'switcher',
			'title'   => esc_html__('Comment Meta', 'tradent' ),
			'info'	  => esc_html__('YES! to show post comment meta information', 'tradent'),
			'default' => true
		  ),

		  array(
			'id'      => 'post-category-meta',
			'type'    => 'switcher',
			'title'   => esc_html__('Category Meta', 'tradent' ),
			'info'	  => esc_html__('YES! to show post category information', 'tradent'),
			'default' => true
		  ),

		  array(
			'id'      => 'post-tag-meta',
			'type'    => 'switcher',
			'title'   => esc_html__('Tag Meta', 'tradent' ),
			'info'	  => esc_html__('YES! to show post tag information', 'tradent'),
			'default' => true
			),
			
			array(
				'id'      => 'post-likes',
				'type'    => 'switcher',
				'title'   => esc_html__('Post Likes', 'tradent' ),
				'info'    => esc_html__('YES! to show post likes information', 'tradent'),
				'default' => true
			),

			array(
				'id'      => 'post-views',
				'type'    => 'switcher',
				'title'   => esc_html__('Post Views', 'tradent' ),
				'info'    => esc_html__('YES! to show post views information', 'tradent'),
				'default' => true
			),

		),
	),

	// -----------------------------------------
	// 404 Options
	// -----------------------------------------
	array(
	  'name'      => '404_options',
	  'title'     => esc_html__('404 Options', 'tradent'),
	  'icon'      => 'fa fa-warning',

		'fields'      => array(

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "404 Message", 'tradent' ),
		  ),
		  
		  array(
			'id'      => 'enable-404message',
			'type'    => 'switcher',
			'title'   => esc_html__('Enable Message', 'tradent' ),
			'info'	  => esc_html__('YES! to enable not-found page message.', 'tradent'),
			'default' => true
		  ),

		  array(
			'id'           => 'notfound-style',
			'type'         => 'select',
			'title'        => esc_html__('Template Style', 'tradent'),
			'options'      => array(
			  'type1' 	   => esc_html__('Modern', 'tradent'),
			  'type2'      => esc_html__('Classic', 'tradent'),
			  'type4'  	   => esc_html__('Diamond', 'tradent'),
			  'type5'      => esc_html__('Shadow', 'tradent'),
			  'type6'      => esc_html__('Diamond Alt', 'tradent'),
			  'type7'  	   => esc_html__('Stack', 'tradent'),
			  'type8'  	   => esc_html__('Minimal', 'tradent'),
			),
			'class'        => 'chosen',
			'default'      => 'type1',
			'info'         => esc_html__('Choose the style of not-found template page.', 'tradent')
		  ),

		  array(
			'id'      => 'notfound-darkbg',
			'type'    => 'switcher',
			'title'   => esc_html__('404 Dark BG', 'tradent' ),
			'info'	  => esc_html__('YES! to use dark bg notfound page for this site.', 'tradent')
		  ),

		  array(
			'id'           => 'notfound-pageid',
			'type'         => 'select',
			'title'        => esc_html__('Custom Page', 'tradent'),
			'options'      => 'pages',
			'class'        => 'chosen',
			'default_option' => esc_html__('Choose the page', 'tradent'),
			'info'       	 => esc_html__('Choose the page for not-found content.', 'tradent')
		  ),
		  
		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Background Options", 'tradent' ),
		  ),

		  array(
			'id'    => 'notfound_background',
			'type'  => 'background',
			'title' => esc_html__('Background', 'tradent')
		  ),

		  array(
			'id'  		 => 'notfound-bg-style',
			'type'  	 => 'textarea',
			'title' 	 => esc_html__('Custom Styles', 'tradent'),
			'info'		 => esc_html__('Paste custom CSS styles for not found page.', 'tradent')
		  ),

		),
	),

	// -----------------------------------------
	// Underconstruction Options
	// -----------------------------------------
	array(
	  'name'      => 'comingsoon_options',
	  'title'     => esc_html__('Under Construction Options', 'tradent'),
	  'icon'      => 'fa fa-thumbs-down',

		'fields'      => array(

		  array(
			'type'    => 'subheading',
			'content' => esc_html__( "Under Construction", 'tradent' ),
		  ),
	
		  array(
			'id'      => 'enable-comingsoon',
			'type'    => 'switcher',
			'title'   => esc_html__('Enable Coming Soon', 'tradent' ),
			'info'	  => esc_html__('YES! to check under construction page of your website.', 'tradent')
		  ),
	
		  array(
			'id'           => 'comingsoon-style',
			'type'         => 'select',
			'title'        => esc_html__('Template Style', 'tradent'),
			'options'      => array(
			  'type1' 	   => esc_html__('Diamond', 'tradent'),
			  'type2'      => esc_html__('Teaser', 'tradent'),
			  'type3'  	   => esc_html__('Minimal', 'tradent'),
			  'type4'      => esc_html__('Counter Only', 'tradent'),
			  'type5'      => esc_html__('Belt', 'tradent'),
			  'type6'  	   => esc_html__('Classic', 'tradent'),
			  'type7'  	   => esc_html__('Boxed', 'tradent')
			),
			'class'        => 'chosen',
			'default'      => 'type1',
			'info'         => esc_html__('Choose the style of coming soon template.', 'tradent'),
		  ),

		  array(
			'id'      => 'uc-darkbg',
			'type'    => 'switcher',
			'title'   => esc_html__('Coming Soon Dark BG', 'tradent' ),
			'info'	  => esc_html__('YES! to use dark bg coming soon page for this site.', 'tradent')
		  ),

		  array(
			'id'           => 'comingsoon-pageid',
			'type'         => 'select',
			'title'        => esc_html__('Custom Page', 'tradent'),
			'options'      => 'pages',
			'class'        => 'chosen',
			'default_option' => esc_html__('Choose the page', 'tradent'),
			'info'       	 => esc_html__('Choose the page for comingsoon content.', 'tradent')
		  ),

		  array(
			'id'      => 'show-launchdate',
			'type'    => 'switcher',
			'title'   => esc_html__('Show Launch Date', 'tradent' ),
			'info'	  => esc_html__('YES! to show launch date text.', 'tradent'),
		  ),

		  array(
			'id'      => 'comingsoon-launchdate',
			'type'    => 'text',
			'title'   => esc_html__('Launch Date', 'tradent'),
			'attributes' => array( 
			  'placeholder' => '10/30/2016 12:00:00'
			),
			'after' 	=> '<p class="cs-text-info">'.esc_html__('Put Format: 12/30/2016 12:00:00 month/day/year hour:minute:second', 'tradent').'</p>',
		  ),

		  array(
			'id'           => 'comingsoon-timezone',
			'type'         => 'select',
			'title'        => esc_html__('UTC Timezone', 'tradent'),
			'options'      => array(
			  '-12' => '-12', '-11' => '-11', '-10' => '-10', '-9' => '-9', '-8' => '-8', '-7' => '-7', '-6' => '-6', '-5' => '-5', 
			  '-4' => '-4', '-3' => '-3', '-2' => '-2', '-1' => '-1', '0' => '0', '+1' => '+1', '+2' => '+2', '+3' => '+3', '+4' => '+4',
			  '+5' => '+5', '+6' => '+6', '+7' => '+7', '+8' => '+8', '+9' => '+9', '+10' => '+10', '+11' => '+11', '+12' => '+12'
			),
			'class'        => 'chosen',
			'default'      => '0',
			'info'         => esc_html__('Choose utc timezone, by default UTC:00:00', 'tradent'),
		  ),

		  array(
			'id'    => 'comingsoon_background',
			'type'  => 'background',
			'title' => esc_html__('Background', 'tradent')
		  ),

		  array(
			'id'  		 => 'comingsoon-bg-style',
			'type'  	 => 'textarea',
			'title' 	 => esc_html__('Custom Styles', 'tradent'),
			'info'		 => esc_html__('Paste custom CSS styles for under construction page.', 'tradent'),
		  ),

		),
	),

  ),
);

// -----------------------------------------
// Widget area Options
// -----------------------------------------
$options[]      = array(
	'name'   => 'widgetarea_options',
	'title'  => esc_html__('Widget Area', 'tradent'),
	'icon'   => 'fa fa-trello',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'content' => esc_html__( "Custom Widget Area for Sidebar", 'tradent' ),
		),
		array(
			'id'      => 'wtitle-style',
			'type'    => 'select',
			'title'   => esc_html__('Sidebar widget Title Style', 'tradent'),
			'options' => array(
				'default' => esc_html__('Choose any type', 'tradent'),
				'type1'   => esc_html__('Double Border', 'tradent'),
				'type2'   => esc_html__('Tooltip', 'tradent'),
				'type3'   => esc_html__('Title Top Border', 'tradent'),
				'type4'   => esc_html__('Left Border & Pattren', 'tradent'),
				'type5'   => esc_html__('Bottom Border', 'tradent'),
				'type6'   => esc_html__('Tooltip Border', 'tradent'),
				'type7'   => esc_html__('Boxed Modern', 'tradent'),
				'type8'   => esc_html__('Elegant Border', 'tradent'),
				'type9'   => esc_html__('Needle', 'tradent'),
				'type10'  => esc_html__('Ribbon', 'tradent'),
				'type11'  => esc_html__('Content Background', 'tradent'),
				'type12'  => esc_html__('Classic BG', 'tradent'),
				'type13'  => esc_html__('Tiny Boders', 'tradent'),
				'type14'  => esc_html__('BG & Border', 'tradent'),
				'type15'  => esc_html__('Classic BG Alt', 'tradent'),
				'type16'  => esc_html__('Left Border & BG', 'tradent'),
				'type17'  => esc_html__('Basic', 'tradent'),
				'type18'  => esc_html__('BG & Pattern', 'tradent'),
			),
			'class'   => 'chosen',
			'default' =>  'default',
			'info'    => esc_html__('Choose the style of sidebar widget title.', 'tradent')
	  	),
	  	array(
			'id'              => 'widgetarea-custom',
			'type'            => 'group',
			'title'           => esc_html__('Custom Widget Area', 'tradent'),
			'button_title'    => esc_html__('Add New', 'tradent'),
			'accordion_title' => esc_html__('Add New Widget Area', 'tradent'),
			'fields'          => array(
				array(
					'id'    => 'widgetarea-custom-name',
					'type'  => 'text',
					'title' => esc_html__('Name', 'tradent'),
				),
			)
		),
	),
);

// -----------------------------------------
// Woocommerce Options
// -----------------------------------------
if( function_exists( 'is_woocommerce' ) && ! class_exists ( 'DTWooPlugin' ) ){

	$options[] = array(
		'name'   => 'woocommerce_options',
		'title'  => esc_html__('Woocommerce', 'tradent'),
		'icon'   => 'fa fa-shopping-cart',
		'fields' => array(
			array(
				'type'    => 'subheading',
				'content' => esc_html__( "Woocommerce Shop Page Options", 'tradent' ),
			),
			array(
				'id'      => 'shop-product-per-page',
				'type'    => 'number',
				'title'   => esc_html__('Products Per Page', 'tradent'),
				'after'   => '<span class="cs-text-desc">&nbsp;'.esc_html__('Number of products to show in catalog / shop page', 'tradent').'</span>',
				'default' => 12,
			),
			array(
				'id'      => 'product-style',
				'type'    => 'select',
				'title'   => esc_html__('Product Style', 'tradent'),
				'options' => array(
					'woo-type1'  => esc_html__('Thick Border', 'tradent'),
					'woo-type4'  => esc_html__('Diamond Icons', 'tradent'),
					'woo-type8'  => esc_html__('Modern', 'tradent'),
					'woo-type10' => esc_html__('Easing', 'tradent'),
					'woo-type11' => esc_html__('Boxed', 'tradent'),
					'woo-type12' => esc_html__('Easing Alt', 'tradent'),
					'woo-type13' => esc_html__('Parallel', 'tradent'),
					'woo-type14' => esc_html__('Pointer', 'tradent'),
					'woo-type16' => esc_html__('Stack', 'tradent'),
					'woo-type17' => esc_html__('Bouncy', 'tradent'),
					'woo-type20' => esc_html__('Masked Circle', 'tradent'),
					'woo-type21' => esc_html__('Classic', 'tradent')
				),
				'class'   => 'chosen',
				'default' => 'woo-type1',
				'info'    => esc_html__('Choose products style to display shop & archive pages.', 'tradent')
			),
			array(
				'id'      => 'shop-page-product-layout',
				'type'    => 'image_select',
				'title'   => esc_html__('Product Layout', 'tradent'),
				'options' => array(
					1 => TRADENT_THEME_URI . '/cs-framework-override/images/one-column.png',
					2 => TRADENT_THEME_URI . '/cs-framework-override/images/one-half-column.png',
					3 => TRADENT_THEME_URI . '/cs-framework-override/images/one-third-column.png',
					4 => TRADENT_THEME_URI . '/cs-framework-override/images/one-fourth-column.png',
				),
				'default'    => 4,
				'attributes' => array(
					'data-depend-id' => 'shop-page-product-layout',
				),
			),
			array(
				'type'    => 'subheading',
				'content' => esc_html__( "Product Detail Page Options", 'tradent' ),
			),
			array(
				'id'      => 'product-layout',
				'type'    => 'image_select',
				'title'   => esc_html__('Layout', 'tradent'),
				'options' => array(
					'content-full-width' => TRADENT_THEME_URI . '/cs-framework-override/images/without-sidebar.png',
					'with-left-sidebar'  => TRADENT_THEME_URI . '/cs-framework-override/images/left-sidebar.png',
					'with-right-sidebar' => TRADENT_THEME_URI . '/cs-framework-override/images/right-sidebar.png',
					'with-both-sidebar'  => TRADENT_THEME_URI . '/cs-framework-override/images/both-sidebar.png',
				),
				'default'    => 'content-full-width',
				'attributes' => array(
					'data-depend-id' => 'product-layout',
				),
			),
			array(
				'id'         => 'show-shop-standard-left-sidebar-for-product-layout',
				'type'       => 'switcher',
				'title'      => esc_html__('Show Shop Standard Left Sidebar', 'tradent'),
				'dependency' => array( 'product-layout', 'any', 'with-left-sidebar,with-both-sidebar' ),
			),
			array(
				'id'         => 'show-shop-standard-right-sidebar-for-product-layout',
				'type'       => 'switcher',
				'title'      => esc_html__('Show Shop Standard Right Sidebar', 'tradent'),
				'dependency' => array( 'product-layout', 'any', 'with-right-sidebar,with-both-sidebar' ),
			),
			array(
				'id'    => 'enable-related',
				'type'  => 'switcher',
				'title' => esc_html__('Show Related Products', 'tradent'),
				'info'  => esc_html__("YES! to display related products on single product's page.", 'tradent')
			),
			array(
				'type'    => 'subheading',
				'content' => esc_html__( "Product Category Page Options", 'tradent' ),
			),
			array(
				'id'      => 'product-category-layout',
				'type'    => 'image_select',
				'title'   => esc_html__('Layout', 'tradent'),
				'options' => array(
					'content-full-width' => TRADENT_THEME_URI . '/cs-framework-override/images/without-sidebar.png',
					'with-left-sidebar'  => TRADENT_THEME_URI . '/cs-framework-override/images/left-sidebar.png',
					'with-right-sidebar' => TRADENT_THEME_URI . '/cs-framework-override/images/right-sidebar.png',
					'with-both-sidebar'  => TRADENT_THEME_URI . '/cs-framework-override/images/both-sidebar.png',
				),
				'default'    => 'content-full-width',
				'attributes' => array(
					'data-depend-id' => 'product-category-layout',
				),
			),
			array(
				'id'         => 'show-shop-standard-left-sidebar-for-product-category-layout',
				'type'       => 'switcher',
				'title'      => esc_html__('Show Shop Standard Left Sidebar', 'tradent'),
				'dependency' => array( 'product-category-layout', 'any', 'with-left-sidebar,with-both-sidebar' ),
			),
			array(
				'id'         => 'show-shop-standard-right-sidebar-for-product-category-layout',
				'type'       => 'switcher',
				'title'      => esc_html__('Show Shop Standard Right Sidebar', 'tradent'),
				'dependency' => array( 'product-category-layout', 'any', 'with-right-sidebar,with-both-sidebar' ),
		  	),
		  	array(
				'type'    => 'subheading',
				'content' => esc_html__( "Product Tag Page Options", 'tradent' ),
		  	),
		  	array(
				'id'      => 'product-tag-layout',
				'type'    => 'image_select',
				'title'   => esc_html__('Layout', 'tradent'),
				'options' => array(
					'content-full-width'   => TRADENT_THEME_URI . '/cs-framework-override/images/without-sidebar.png',
					'with-left-sidebar'    => TRADENT_THEME_URI . '/cs-framework-override/images/left-sidebar.png',
					'with-right-sidebar'   => TRADENT_THEME_URI . '/cs-framework-override/images/right-sidebar.png',
					'with-both-sidebar'    => TRADENT_THEME_URI . '/cs-framework-override/images/both-sidebar.png',
				),
				'default'    => 'content-full-width',
				'attributes' => array(
					'data-depend-id' => 'product-tag-layout',
				),
			),
			array(
				'id'         => 'show-shop-standard-left-sidebar-for-product-tag-layout',
				'type'       => 'switcher',
				'title'      => esc_html__('Show Shop Standard Left Sidebar', 'tradent'),
				'dependency' => array( 'product-tag-layout', 'any', 'with-left-sidebar,with-both-sidebar' ),
			),
			array(
				'id'         => 'show-shop-standard-right-sidebar-for-product-tag-layout',
				'type'       => 'switcher',
				'title'      => esc_html__('Show Shop Standard Right Sidebar', 'tradent'),
				'dependency' => array( 'product-tag-layout', 'any', 'with-right-sidebar,with-both-sidebar' ),
			),
		),
	);
}

// -----------------------------------------
// Sociable Options
// -----------------------------------------
$options[] = array(
	'name'   => 'sociable_options',
	'title'  => esc_html__('Sociable', 'tradent'),
	'icon'   => 'fa fa-share-alt-square',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'content' => esc_html__( "Sociable", 'tradent' ),
		),
		array(
			'id'              => 'sociable_fields',
			'type'            => 'group',
			'title'           => esc_html__('Sociable', 'tradent'),
			'info'            => esc_html__('Click button to add type of social & url.', 'tradent'),
			'button_title'    => esc_html__('Add New Social', 'tradent'),
			'accordion_title' => esc_html__('Adding New Social Field', 'tradent'),
			'fields'          => array(
				array(
					'id'      => 'sociable_fields_type',
					'type'    => 'select',
					'title'   => esc_html__('Select Social', 'tradent'),
					'options' => array(
						'delicious'   => esc_html__('Delicious', 'tradent'),
						'deviantart'  => esc_html__('Deviantart', 'tradent'),
						'digg'        => esc_html__('Digg', 'tradent'),
						'dribbble'    => esc_html__('Dribbble', 'tradent'),
						'envelope'    => esc_html__('Envelope', 'tradent'),
						'facebook'    => esc_html__('Facebook', 'tradent'),
						'flickr'      => esc_html__('Flickr', 'tradent'),
						'google-plus' => esc_html__('Google Plus', 'tradent'),
						'gtalk'       => esc_html__('GTalk', 'tradent'),
						'instagram'   => esc_html__('Instagram', 'tradent'),
						'lastfm'      => esc_html__('Lastfm', 'tradent'),
						'linkedin'    => esc_html__('Linkedin', 'tradent'),
						'myspace'     => esc_html__('Myspace', 'tradent'),
						'picasa'      => esc_html__('Picasa', 'tradent'),
						'pinterest'   => esc_html__('Pinterest', 'tradent'),
						'reddit'      => esc_html__('Reddit', 'tradent'),
						'rss'         => esc_html__('RSS', 'tradent'),
						'skype'       => esc_html__('Skype', 'tradent'),
						'stumbleupon' => esc_html__('Stumbleupon', 'tradent'),
						'technorati'  => esc_html__('Technorati', 'tradent'),
						'tumblr'      => esc_html__('Tumblr', 'tradent'),
						'twitter'     => esc_html__('Twitter', 'tradent'),
						'viadeo'      => esc_html__('Viadeo', 'tradent'),
						'vimeo'       => esc_html__('Vimeo', 'tradent'),
						'yahoo'       => esc_html__('Yahoo', 'tradent'),
						'youtube'     => esc_html__('Youtube', 'tradent'),
					),
					'class'   => 'chosen',
					'default' => 'delicious',
				),
				array(
					'id'    => 'sociable_fields_url',
					'type'  => 'text',
					'title' => esc_html__('Enter URL', 'tradent')
				),
			)
		),
	),
);

// -----------------------------------------
// Hook Options
// -----------------------------------------
$options[] = array(
	'name'   => 'hook_options',
	'title'  => esc_html__('Hooks', 'tradent'),
	'icon'   => 'fa fa-paperclip',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'content' => esc_html__( "Top Hook", 'tradent' ),
		),
		array(
			'id'    => 'enable-top-hook',
			'type'  => 'switcher',
			'title' => esc_html__('Enable Top Hook', 'tradent'),
			'info'  => esc_html__("YES! to enable top hook.", 'tradent')
		),
		array(
			'id'    => 'top-hook',
			'type'  => 'textarea',
			'title' => esc_html__('Top Hook', 'tradent'),
			'info'  => esc_html__('Paste your top hook, Executes after the opening &lt;body&gt; tag.', 'tradent')
		),
		array(
			'type'    => 'subheading',
			'content' => esc_html__( "Content Before Hook", 'tradent' ),
	  	),
	  	array(
	  		'id'  	=> 'enable-content-before-hook',
	  		'type'  => 'switcher',
	  		'title' => esc_html__('Enable Content Before Hook', 'tradent'),
	  		'info'	=> esc_html__("YES! to enable content before hook.", 'tradent')
	  	),
	  	array(
			'id'    => 'content-before-hook',
			'type'  => 'textarea',
			'title' => esc_html__('Content Before Hook', 'tradent'),
			'info'  => esc_html__('Paste your content before hook, Executes before the opening &lt;#primary&gt; tag.', 'tradent')
	  	),
	  	array(
			'type'    => 'subheading',
			'content' => esc_html__( "Content After Hook", 'tradent' ),
	  	),
	  	array(
			'id'    => 'enable-content-after-hook',
			'type'  => 'switcher',
			'title' => esc_html__('Enable Content After Hook', 'tradent'),
			'info'  => esc_html__("YES! to enable content after hook.", 'tradent')
	  	),
	  	array(
			'id'    => 'content-after-hook',
			'type'  => 'textarea',
			'title' => esc_html__('Content After Hook', 'tradent'),
			'info'  => esc_html__('Paste your content after hook, Executes after the closing &lt;/#main&gt; tag.', 'tradent')
	  	),
	  	array(
			'type'    => 'subheading',
			'content' => esc_html__( "Bottom Hook", 'tradent' ),
	  	),
	  	array(
	  		'id'  	=> 'enable-bottom-hook',
	  		'type'  => 'switcher',
	  		'title' => esc_html__('Enable Bottom Hook', 'tradent'),
	  		'info'	=> esc_html__("YES! to enable bottom hook.", 'tradent')
	  	),
	  	array(
			'id'    => 'bottom-hook',
			'type'  => 'textarea',
			'title' => esc_html__('Bottom Hook', 'tradent'),
			'info'  => esc_html__('Paste your bottom hook, Executes after the closing &lt;/body&gt; tag.', 'tradent')
	  	),
	  	array(
	  		'id'  	=> 'enable-analytics-code',
	  		'type'  => 'switcher',
	  		'title' => esc_html__('Enable Tracking Code', 'tradent'),
	  		'info'	=> esc_html__("YES! to enable site tracking code.", 'tradent')
	  	),
	  	array(
	  		'id'    => 'analytics-code',
	  		'type'  => 'textarea',
	  		'title' => esc_html__('Google Analytics Tracking Code', 'tradent'),
	  		'info'  => esc_html__('Enter your Google tracking id (UA-XXXXX-X) here. If you want to offer your visitors the option to stop being tracked you can place the shortcode [dt_sc_privacy_google_tracking] somewhere on your site', 'tradent')
	  	),
	),
);

// ------------------------------
// backup                       
// ------------------------------
$options[] = array(
	'name'   => 'backup_section',
	'title'  => esc_html__('Backup', 'tradent'),
	'icon'   => 'fa fa-shield',
	'fields' => array(
		array(
			'type'    => 'notice',
			'class'   => 'warning',
			'content' => esc_html__('You can save your current options. Download a Backup and Import.', 'tradent')
		),
		array(
			'type' => 'backup',
		),
	)
);

// ------------------------------
// license
// ------------------------------
$options[] = array(
	'name'   => 'theme_version',
	'title'  => constant('TRADENT_THEME_NAME').esc_html__(' Log', 'tradent'),
	'icon'   => 'fa fa-info-circle',
	'fields' => array(
		array(
			'type'    => 'heading',
			'content' => constant('TRADENT_THEME_NAME').esc_html__(' Theme Change Log', 'tradent')
		),
		array(
			'type'    => 'content',
			'content' => '<pre>

2020.02.01 - version 1.8

	* Compatible with wordpress 5.3.2
	* Updated: All premium plugins
	* Updated: All wordpress theme standards
	* Updated: Privacy and Cookies concept

	* Fixed: Google Analytics issue
	* Fixed: Privacy Button Issue

	* Improved: Single product breadcrumb section
	* Improved: Revisions options added for all custom posts
			
2019.11.11 - version 1.7
	* Compatible with wordpress 5.2.4
	* Updated: All wordpress theme standards
	* Updated: All premium plugins
	* Updated: Revisions added to all custom post types
	* Updated: Gutenberg editor support for custom post types
	* Updated: Link for phone number module
	* Updated: language files

	* Fixed: Mailchimp email client issue
	* Fixed: Gutenberg check for old wordpress version
	* Fixed: Edit with Visual Composer for portfolio
	* Fixed: Header & Footer wpml option
	* Fixed: Site title color
	* Fixed: Privacy popup bg color

	* Improved: Tags taxonomy added for portfolio
	* Improved: Woocommerce cart module added with custom class option

	* New: Whatsapp Shortcode
				
2019.05.20 - version 1.6
	* Gutenberg Latest fixes
	* Updated Visual Composer and Layer slider plugins

2019.05.03 - version 1.5
	* Gutenberg Latest update compatible
	* Portfolio Video option
	* Coming Soon page fix
	* Portfolio archive page breadcrumb fix
	* Mega menu image fix
	* GDPR product single page fix
	* Codestar framework update
	* Wpml xml file updated
	* disable options for likes and views in single post page
	* Updated latest version of all third party plugins
	* Some design tweaks

2019.02.05 - version 1.4
	* Gutenberg compatible
	* Latest WordPress version 5.0.3 compatible
	* Updated latest version of all third party plugins
	* Some design tweaks

2018.11.03 - version 1.3
	* Gutenberg plugin compatible
	* Latest wordpress version 4.9.8 compatible
	* Updated latest version of all third party plugins
	* Updated documentation

2018.07.27 - version 1.2
	* GDPR Compliant update in comment form, mailchimp form etc.
	* Packed with - Layer Slider 6.7.6
	* Packed with - Revolution Slider 5.4.8
	* Packed with - WPBakery Page Builder 5.5.2
	* Packed with - Ultimate Addons for Visual Composer 3.16.24
	* Packed with - Envato Market 2.0.0
	* Fix - Option for change the site title color
	* Fix - Add target attribute for social media
	* Fix - Bulk plugins install issue
	* Fix - Unyson Page Builder Conflict
	* Fix - Twitter feeds links issue
	* Fix - Iphone sidebar issue
	* Fix - Buddypress issue
	* Fix - Youtube and Vimeo video issue in https
	* Updated designthemes core features plugin
	* Updated language files

2018.04.18 - version 1.1
	* Updated dummy data

2018.04.16 - version 1.0
	* First release!</pre>',
    ),

  )
);

// ------------------------------
// Seperator
// ------------------------------
$options[] = array(
  'name'   => 'seperator_1',
  'title'  => esc_html__('Plugin Options', 'tradent'),
  'icon'   => 'fa fa-plug'
);

CSFramework::instance( $settings, $options );